export interface IFile {
    label: string,
    link: string
}
