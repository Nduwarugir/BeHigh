import { Injectable } from '@angular/core';
import { Observable, from } from 'rxjs';
// import { arp, ArpEntry } from "node-arp";


@Injectable({
    providedIn: 'root'
})
export class NetworkScanService {

    constructor() { }

    // scanNetwork(): Observable<ArpEntry[]> {
	// 	return from(arp.table()).pipe();
    // }
}
