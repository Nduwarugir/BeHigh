import { Injectable } from '@angular/core';
// import { Plugins } from '@capacitor/core';
// import { Network } from '@capacitor/network';
// import { Network } from "@awesome-cordova-plugins/network";


@Injectable({
    providedIn: 'root'
})
export class NetworkScanService {
  
    constructor() { }
    
    ipAddress!: string;

    getIpAddress() {
    }
}