export interface IAdmin {
    auth: boolean,
    user: string,
    pass: string
}
