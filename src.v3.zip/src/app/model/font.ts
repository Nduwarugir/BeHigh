export interface IFont {
    type: string
}
