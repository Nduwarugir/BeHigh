import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./tabs/tabs.routes').then((m) => m.routes),
  },
  {
    path: 'text',
    loadComponent: () => import('./tab2/text/text.page').then( m => m.TextPage)
  },
  {
    path: 'video',
    loadComponent: () => import('./tab2/video/video.page').then( m => m.VideoPage)
  },
  {
    path: 'effet',
    loadComponent: () => import('./tab2/effet/effet.page').then( m => m.EffetPage)
  },
  {
    path: 'image',
    loadComponent: () => import('./tab2/image/image.page').then( m => m.ImagePage)
  },
  {
    path: 'global-information',
    loadComponent: () => import('./tab3/global-information/global-information.page').then( m => m.GlobalInformationPage)
  },
  {
    path: 'network-configuration',
    loadComponent: () => import('./tab3/network-configuration/network-configuration.page').then( m => m.NetworkConfigurationPage)
  },
  {
    path: 'network-information',
    loadComponent: () => import('./tab3/network-information/network-information.page').then( m => m.NetworkInformationPage)
  },
  {
    path: 'ntp-settings',
    loadComponent: () => import('./tab3/ntp-settings/ntp-settings.page').then( m => m.NtpSettingsPage)
  },
  {
    path: 'system-settings',
    loadComponent: () => import('./tab3/system-settings/system-settings.page').then( m => m.SystemSettingsPage)
  },
  {
    path: 'edit',
    loadComponent: () => import('./tab3/system-settings/edit/edit.page').then( m => m.EditPage)
  },
  {
    path: 'update',
    loadComponent: () => import('./tab3/system-settings/update/update.page').then( m => m.UpdatePage)
  },
];
