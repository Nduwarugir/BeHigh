export interface IAdmin {
    id: number,
    login: string,
    password: string
}
