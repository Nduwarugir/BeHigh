import {Injectable} from "@angular/core";
import {IAdmin} from "../model/admin";
import {IScenario} from "../model/scenario";
import { IWifiConfig } from "../model/wifi-config";

@Injectable()
export class GlobalVariables {

    currentUserData: IAdmin = <IAdmin>{};

    isConnected!: Boolean;

    globalScenario: IScenario[] = [];

    clearScenario() {
        this.globalScenario = [];
    }

    addScriptToScenario(position: number, script: IScenario) {
        this.globalScenario.splice(position, 1, script);
        console.log("Script ajouté", script);
        console.log("All Scripts", this.globalScenario);
    }


    globalWifiConfig: IWifiConfig = <IWifiConfig>{};

    setWifiConfig(wifiConfig: IWifiConfig) {
        this.globalWifiConfig = wifiConfig;
    }

    globalDate: Date = new Date()

    setGlobalDate(date: Date) {
        this.globalDate = date;
    }

}
