import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NtpSettingsPage } from './ntp-settings.page';

describe('NtpSettingsPage', () => {
  let component: NtpSettingsPage;
  let fixture: ComponentFixture<NtpSettingsPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(NtpSettingsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
