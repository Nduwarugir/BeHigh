import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Router } from 'express';
import { GlobalVariables } from 'src/app/shared/global-variables';
// import * as moment from 'moment-timezone';

@Component({
  selector: 'app-ntp-settings',
  templateUrl: './ntp-settings.page.html',
  styleUrls: ['./ntp-settings.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule]
})
export class NtpSettingsPage implements OnInit {
    public title = 'SNTP';
    form! : FormGroup;
    protected errMsg!: string;
    protected _mode: string = 'auto';
    protected _other: number = 0;
    protected date: Date = new Date();
    timesZone: { value: string, label: string }[] = [];

    constructor(private fb: FormBuilder, private param: GlobalVariables, private route: Router) {
        this.form = this.fb.group({
            timeMode:['auto', Validators.required],
            // Sntp Auto Configuration
            server1:['Sa', Validators.required],
            server2:['Sb', Validators.required],
            server3:['Sc', Validators.required],
            timeZone:[Intl.DateTimeFormat().resolvedOptions().timeZone, Validators.required],
            // Sntp Manual Configuration
            year:[this.date.getFullYear(), Validators.required],
            month:[(this.date.getMonth()+1).toString().padStart(2, '0'), Validators.required],
            date:[this.date.getDate().toString().padStart(2, '0'), Validators.required],
            hour:[this.date.getHours().toString().padStart(2, '0'), Validators.required],
            minute:[this.date.getMinutes().toString().padStart(2, '0'), Validators.required],
            seconde:[this.date.getSeconds().toString().padStart(2, '0'), Validators.required],
        })
    }

    ngOnInit(): void {
        // this.timesZone = moment.tz.names().map(zone => ({ value: zone, label: zone}));
    }

    submit(): void {
        if (this.form.valid) {
            this.form.value.year = Number(this.form.value.year);
            this.form.value.month = Number(this.form.value.month);
            this.form.value.date = Number(this.form.value.date);
            this.form.value.hour = Number(this.form.value.hour);
            this.form.value.minute = Number(this.form.value.minute);
            this.form.value.seconde = Number(this.form.value.seconde);
            console.log("SNTP: ", this.form.value);
            this.param.setGlobalDate(this.getDate());
            this.refresh();
        } else {
            console.log(this.errMsg);
        }
    }

    refresh(): void {
        // this.route.navigateByUrl('/admin', {
        //     skipLocationChange: false
        // }).then(() => {
        //     this.route.navigate(['/home']);
        // })
    }

    getDate(): Date {
        if (this._mode == 'manual') {
            this.date = new Date(this.form.value.year,this.form.value.month-1,this.form.value.date,this.form.value.hour,this.form.value.minute,this.form.value.seconde);
        }
        return this.date; //.toLocaleString('fr-FR', this.form.value.timeZone);
    }

    setMode(mode: string) {
        this._mode = mode;
    }

    get mode(): string {
        return this._mode;
    }

    setOther(n: number) {
        this._other = n;
    }

    get other(): number {
        return this._other;
    }

    range(f: number, l: number): string[] {
        const array: string[] = [];

        for (let i = f; i <= l; i++) {
            array.push(i.toString().padStart(2, '0'))
        }
        return array;
    }
}
