import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { EditPage } from './edit/edit.page';
import { UpdatePage } from './update/update.page';

@Component({
  selector: 'app-system-settings',
  templateUrl: './system-settings.page.html',
  styleUrls: ['./system-settings.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, EditPage, UpdatePage]
})
export class SystemSettingsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
