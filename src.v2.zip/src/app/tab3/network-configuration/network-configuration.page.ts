import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { IWifiConfig } from '../../model/wifi-config';

@Component({
    selector: 'app-network-configuration',
    templateUrl: './network-configuration.page.html',
    styleUrls: ['./network-configuration.page.scss'],
    standalone: true,
    imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule]
})
export class NetworkConfigurationPage implements OnInit {

    form! : FormGroup;
    _disabled!: boolean;

    wifiConfig!: IWifiConfig;

    ngOnInit(){
        this.read();
        this.load();
    }

    //On verifie que chaque champ soit remplir
    constructor(private fb : FormBuilder){

        this.form= this.fb.group({
            modeap:['', Validators.nullValidator],
            ssid:['', Validators.required],
            password:['', Validators.required],
            dhcp:['', Validators.required],
            ip1:['', Validators.required],
            ip2:['', Validators.required],
            ip3:['', Validators.required],
            ip4:['', Validators.required],
            netmask1:['', Validators.required],
            netmask2:['', Validators.required],
            netmask3:['', Validators.required],
            netmask4:['', Validators.required],
            gateway1:['', Validators.required],
            gateway2:['', Validators.required],
            gateway3:['', Validators.required],
            gateway4:['', Validators.required],
            dns1:['', Validators.required],
            dns2:['', Validators.required],
            dns3:['', Validators.required],
            dns4:['', Validators.required],
        });
    }

    disable(event: any): void {

        // Désactivation des configs
        this.dhcp?.valueChanges.subscribe(
            (val) => {
                if (val) {
                    this._disabled = true;
                    this.ip1?.disable(); this.ip2?.disable(); this.ip3?.disable(); this.ip4?.disable();
                    this.netmask1?.disable(); this.netmask2?.disable(); this.netmask3?.disable(); this.netmask4?.disable();
                    this.gateway1?.disable(); this.gateway2?.disable(); this.gateway3?.disable(); this.gateway4?.disable();
                    this.dns1?.disable(); this.dns2?.disable(); this.dns3?.disable(); this.dns4?.disable();


                    // Opérations pour le DHCP
                    // Example define the default DNS
                    this.wifiConfig.dns = [0,0,0,0];

                } else {
                    this._disabled = false;
                    this.ip1?.enable(); this.ip2?.enable(); this.ip3?.enable(); this.ip4?.enable();
                    this.netmask1?.enable(); this.netmask2?.enable(); this.netmask3?.enable(); this.netmask4?.enable();
                    this.gateway1?.enable(); this.gateway2?.enable(); this.gateway3?.enable(); this.gateway4?.enable();
                    this.dns1?.enable(); this.dns2?.enable(); this.dns3?.enable(); this.dns4?.enable();
                }

            }
        )

    }

    submit() {

        if (this.form.valid) {

            if (Number.isNaN(Number(this.ip1?.value)) || Number.isNaN(Number(this.ip2?.value)) || Number.isNaN(Number(this.ip3?.value)) || Number.isNaN(Number(this.ip4?.value)) ) {
                console.log("Null IP");
                this.setError(1);
            } else if (Number.isNaN(Number(this.netmask1?.value)) || Number.isNaN(Number(this.netmask2?.value)) || Number.isNaN(Number(this.netmask3?.value)) || Number.isNaN(Number(this.netmask4?.value)) ) {
                console.log("Null NETMASK");
                this.setError(2);
            } else if (Number.isNaN(Number(this.gateway1?.value)) || Number.isNaN(Number(this.gateway2?.value)) || Number.isNaN(Number(this.gateway3?.value)) || Number.isNaN(Number(this.gateway4?.value)) ) {
                console.log("Null GATEWAY");
                this.setError(3);
            } else if (Number.isNaN(Number(this.dns1?.value)) || Number.isNaN(Number(this.dns2?.value)) || Number.isNaN(Number(this.dns3?.value)) || Number.isNaN(Number(this.dns4?.value)) ) {
                console.log("Null DNS");
                this.setError(4);
            } else {
                this.formToConfig();
                console.log("WifiConfig: ", this.wifiConfig);

            }

        }

    }

    load() {
        if (this.wifiConfig) {
            this.form.patchValue({
                modeap: this.wifiConfig.Wifi_Mode,
                ssid: this.wifiConfig.ssid,
                password: this.wifiConfig.password,
                dhcp: this.wifiConfig.dhcp,
                ip1: this.wifiConfig.ip[0],
                ip2: this.wifiConfig.ip[1],
                ip3: this.wifiConfig.ip[2],
                ip4: this.wifiConfig.ip[3],
                netmask1: this.wifiConfig.netmask[0],
                netmask2: this.wifiConfig.netmask[1],
                netmask3: this.wifiConfig.netmask[2],
                netmask4: this.wifiConfig.netmask[3],
                gateway1: this.wifiConfig.gateway[0],
                gateway2: this.wifiConfig.gateway[1],
                gateway3: this.wifiConfig.gateway[2],
                gateway4: this.wifiConfig.gateway[3],
                dns1: this.wifiConfig.dns[0],
                dns2: this.wifiConfig.dns[1],
                dns3: this.wifiConfig.dns[2],
                dns4: this.wifiConfig.dns[3],
            });
        }
    }

    refresh() {
        console.log("Form Values", this.form.value);

        console.log("wifiConfig: ", this.wifiConfig);
    }

    read() {
        // fetch('http://10.1.1.1/jsonFiles/config.json')
        fetch('assets/json/config.json')
            .then(response => response.json())
            .then(data => {
                // use the 'data' variable which contains the parsed JSON data
                this.wifiConfig = data;

            })
            .catch(error => {
                // handle any errors that occur during the fetch request
                console.error(error);
            });
    }

    // Gestion de l'erreur
    private _err: number = 0;

    setError(n: number){
        this._err = n;
    }

    get error(){
        return this._err;
    }

    //Les getters
    get modeap(){
        return this.form.get('modeap');
    }

    get ssid(){
        return this.form.get('ssid');
    }

    get password(){
        return this.form.get('password');
    }

    get dhcp(){
        return this.form.get('dhcp');
    }

    get ip1(){
        return this.form.get('ip1');
    }


    get ip2(){
        return this.form.get('ip2');
    }

    get ip3(){
        return this.form.get('ip3');
    }

    get ip4(){
        return this.form.get('ip4');
    }

    get netmask1(){
        return this.form.get('netmask1');
    }

    get netmask2(){
        return this.form.get('netmask2');
    }

    get netmask3(){
        return this.form.get('netmask3');
    }

    get netmask4(){
        return this.form.get('netmask4');
    }

    get gateway1(){
        return this.form.get('gateway1');
    }

    get gateway2(){
        return this.form.get('gateway2');
    }

    get gateway3(){
        return this.form.get('gateway3');
    }

    get gateway4(){
        return this.form.get('gateway4');
    }

    get dns1(){
        return this.form.get('dns1');
    }

    get dns2(){
        return this.form.get('dns2');
    }

    get dns3(){
        return this.form.get('dns3');
    }

    get dns4(){
        return this.form.get('dns4');
    }

    formToConfig() {

        if (Number.isNaN(Number(this.ip1?.value)) || Number.isNaN(Number(this.ip2?.value)) || Number.isNaN(Number(this.ip3?.value)) || Number.isNaN(Number(this.ip4?.value)) ) {
            console.log("Null ip");
            this.setError(1);
        } else if (Number.isNaN(Number(this.netmask1?.value)) || Number.isNaN(Number(this.netmask2?.value)) || Number.isNaN(Number(this.netmask3?.value)) || Number.isNaN(Number(this.netmask4?.value)) ) {
            console.log("Null netmask");
            this.setError(2);
        } else if (Number.isNaN(Number(this.gateway1?.value)) || Number.isNaN(Number(this.gateway2?.value)) || Number.isNaN(Number(this.gateway3?.value)) || Number.isNaN(Number(this.gateway4?.value)) ) {
            console.log("Null gateway");
            this.setError(3);
        } else if (Number.isNaN(Number(this.dns1?.value)) || Number.isNaN(Number(this.dns2?.value)) || Number.isNaN(Number(this.dns3?.value)) || Number.isNaN(Number(this.dns4?.value)) ) {
            console.log("Null dns");
            this.setError(4);
        } else {

            console.log("Form: ", this.form.value);

            this.wifiConfig.Wifi_Mode = this.modeap?.value;
            this.wifiConfig.ssid = this.ssid?.value;
            this.wifiConfig.password= this.password?.value;
            this.wifiConfig.dhcp = this.dhcp?.value;
            this.wifiConfig.ip = [Number(this.ip1?.value), Number(this.ip2?.value), Number(this.ip3?.value), Number(this.ip4?.value)];
            this.wifiConfig.netmask = [Number(this.netmask1?.value), Number(this.netmask2?.value), Number(this.netmask3?.value), Number(this.netmask4?.value)];
            this.wifiConfig.gateway = [Number(this.gateway1?.value), Number(this.gateway2?.value), Number(this.gateway3?.value), Number(this.gateway4?.value)];
            this.wifiConfig.dns = [Number(this.dns1?.value), Number(this.dns2?.value), Number(this.dns3?.value), Number(this.dns4?.value)];

        }

    }

}
