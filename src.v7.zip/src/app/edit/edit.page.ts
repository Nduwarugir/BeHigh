import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

@Component({
    selector: 'app-edit',
    templateUrl: './edit.page.html',
    styleUrls: ['./edit.page.scss'],
    standalone: true,
    imports: [IonicModule, CommonModule, FormsModule]
})
export class EditPage implements OnInit {

    @ViewChild('loadingMsg') loadingMsgRef!: ElementRef;
    @ViewChild('loading') loadingRef!: ElementRef;

    constructor() { }

    ngOnInit() {
        this.setLoading('show: any, message: any', 'hello');
    }

    onBodyLoad(): void {
    	console.log('onBodyLoad() call');
    }
    
    
    setLoading(show: any, message: any) {
        // const loadingMsg: HTMLElement = this.loadingMsgRef.nativeElement;
        // if (message) loadingMsg.innerHTML = message;

        console.log('loadingMsgRef', this.loadingMsgRef);
        console.log('loadingRef', this.loadingRef);
        

        // const loading: HTMLElement = this.loadingRef.nativeElement;
        // if (show) loading.classList.add("shown");
        // else loading.classList.remove("shown");
        // document.body.style.cursor = show ? "wait" : "default";
    }
}
