export interface IAnim {
    type: string
}
