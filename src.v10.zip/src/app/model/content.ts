export interface IContent {
    name: string,
    type: string,
    size: string
}
